# BOJ-Color-Label

BOJ 유저 정보란의 문제 번호들을 해당 문제의 티어색으로 칠해주는 확장

![default](https://cdn.discordapp.com/attachments/750756917869150242/861564443439005696/2021-07-05_8.09.26.png)
![des](https://cdn.discordapp.com/attachments/750756917869150242/861564514385657856/2021-07-05_8.09.44.png)

# 확장 적용시키는 법

https://chrome.google.com/webstore/detail/tierimnida/mgdddbhbedfjdodjccjefgbdgkglokdg
